# Here is Your Drive Folder Name You can Replace it with Your Desire name(Optional)
drive_folder_name = "U2GD_bot"

# Enter Your Mega email And Pass (Required)
MEGA_EMAIL = "email"
MEGA_PASSWORD = "password"

START = "Hi {}  \nI am Upload 2 Drive Bot.\nPlease Authorise To use me.\nBy using /auth \n\nFor more info /help\n\nPlease Report Bugs @aryanvikash"

HELP = """<b>AUTHORISE BOT</b>
Use  /auth Command Generate
Your Google Drive Token And
Send It To Bot.\n\n
<b>You Wanna Change Your Login
Account ?</b>
You can use /revoke
command.\n\n
<b>What I Can Do With This Bot?</b>
You Can Upload Any Internet
Files On Your google
Drive Account.\n\n
This Bot is by @Bhadoo\n
Bug Report @aryanvikash"""

DP_DOWNLOAD = "Dropbox Link !! Downloading Started ..."
OL_DOWNLOAD = "Openload Link !! Downloading Started ... \nOpenload Links Are Extremely Slow"
PROCESSING = "Processing Your Request ...!!"
DOWN_TWO = True
DOWNLOAD = "Downloading Started ..."
DOWN_MEGA = "Downloading Started... \nMega Links are \nExtremely Slow :("
DOWN_COMPLETE = "Downloading complete!!"
NOT_AUTH = "You Are Not Authorised To Using this Bot \n\nPlease Authorise Me Using /auth"
REVOKE_FAIL = "You Are Already UnAuthorised. \n\nPlease Use /auth To Authorise. \n\nreport At @aryanvikash "
AUTH_SUCC = "Authorised Successfully  !! \n\nNow Send me A direct Link :)"
ALREADY_AUTH = "You Are Already Authorised!\n\nWanna Change Drive Account? \n\nUse /revoke \n\nreport At @aryanvikash "
AUTH_URL = '<a href ="{}">Click Here to Get Auth Code</a>\n\nGenerate And Copy Your Google Drive Token And Send It To Me'
UPLOADING = "Download Complet !! \nUploading Your file"
REVOKE_TOK = " Your Token is Revoked Successfully!! \n\nUse /auth To Re-Authorise Your Drive Acc."
# DOWN_PATH = "Downloads\\" #windows path
DOWN_PATH = "Downloads/"  # Linux path
DOWNLOAD_URL = "Your File Uploaded Successfully.\n\n <b>Filename</b> : {} \n\n <b> Size</b> : {} MB \n\n <b>Download</b> {}"
AUTH_ERROR = "AUTH Error!! Please Send Me a valid Token or Re-Authorise Me\n\n/auth\n\n report At @aryanvikash"
OPENLOAD = True
DROPBOX = True
MEGA = True


UPDATE = """Try @BhadooCloud"""
